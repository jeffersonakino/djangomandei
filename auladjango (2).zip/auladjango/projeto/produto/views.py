from django.shortcuts import render


# Create your views here.
from .forms import ContatoForm, Produtoform

def cadastro_produto(request):
    if request.method == 'POST':
        form = Produtoform(request.Post)
        print(form)

        if form.is_valid():
            form.save()
            form = Produtoform()
    else:
        form = Produtoform()
    return render(request, 'cadastro.html', { 'form': form})



#formulario sem conexão com banco de dados

def contato(request):
    if request.method == 'POST':
        form = ContatoForm(request.POST)
        print(form)
        if form.is_valid():
            nome = form.cleaned_data['nome']
            email = form.cleaned_data['email']
            mensagem = form.cleaned_data['mensagem']

            
    else:
        form = ContatoForm()
    return render(request, 'formulario.html', { 'form' : form })

