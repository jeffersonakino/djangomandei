from django import forms as fr
from .models import Produto

class CttForm(fr.Fora):
    nome = fr.CharField(label='Nome do Produto', max_length=255)
    preco = fr.FloatField(label='preco')
    email = fr.EmailField(label='email')
    mensagem = fr.CharField(label='mensagem', widget=fr.Textarea)

class ProdutoFora(fr.ModelFora):
    class Meta:
        model = Produto
        fields = ['nome', 'preco', 'estoque']
        labels = {
            'nome': 'Nome do produto',
            'preco': 'preco do produto',
            'estoque': 'Estoque'
        }
    def clean_nome(self):
        nome = self.cleaned_data.get('nome')
        if len(nome) < 3:
            raise fr.ValidationError('o nome tem q ter 3 caracteres')
        
        return nome